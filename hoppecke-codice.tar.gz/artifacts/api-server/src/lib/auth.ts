import crypto from "crypto";

const SECRET = process.env.SESSION_SECRET || "hoppecke-secret-fallback";
const TOKEN_EXPIRY_MS = 30 * 24 * 60 * 60 * 1000;

export function createToken(username: string): string {
  const exp = Date.now() + TOKEN_EXPIRY_MS;
  const payload = Buffer.from(JSON.stringify({ username, exp })).toString("base64url");
  const sig = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export function verifyToken(token: string): { username: string } | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 2) return null;
    const [payload, sig] = parts;
    const expectedSig = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
    const sigBuf = Buffer.from(sig, "base64url");
    const expSigBuf = Buffer.from(expectedSig, "base64url");
    if (sigBuf.length !== expSigBuf.length) return null;
    if (!crypto.timingSafeEqual(sigBuf, expSigBuf)) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (Date.now() > data.exp) return null;
    return { username: data.username };
  } catch {
    return null;
  }
}

export function validateCredentials(username: string, password: string): boolean {
  const validUsername = process.env.AUTH_USERNAME || "hoppecke.admin";
  const validPassword = process.env.AUTH_PASSWORD || "Hck!C0llaud0@2026";
  const usernameMatch = crypto.timingSafeEqual(
    Buffer.from(username),
    Buffer.from(validUsername)
  );
  const passwordMatch = crypto.timingSafeEqual(
    Buffer.from(password),
    Buffer.from(validPassword)
  );
  return usernameMatch && passwordMatch;
}
