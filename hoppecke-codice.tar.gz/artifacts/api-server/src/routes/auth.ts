import { Router } from "express";
import { createToken, validateCredentials } from "../lib/auth.js";

const router = Router();

router.post("/auth/login", (req, res) => {
  const { username, password } = req.body ?? {};
  if (!username || !password) {
    res.status(400).json({ error: "Username e password obbligatori" });
    return;
  }
  try {
    if (!validateCredentials(String(username), String(password))) {
      res.status(401).json({ error: "Credenziali non valide" });
      return;
    }
    const token = createToken(String(username));
    res.json({ token, username });
  } catch {
    res.status(401).json({ error: "Credenziali non valide" });
  }
});

router.post("/auth/logout", (_req, res) => {
  res.json({ success: true });
});

export default router;
