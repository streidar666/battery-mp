import { Router } from "express";
import { db, collaudoRecords } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/collaudo", async (_req, res) => {
  try {
    const records = await db
      .select()
      .from(collaudoRecords)
      .orderBy(desc(collaudoRecords.created_at));
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: "Errore nel recupero dei record" });
  }
});

router.post("/collaudo", async (req, res) => {
  try {
    const body = req.body;
    const [record] = await db
      .insert(collaudoRecords)
      .values({
        id: body.id,
        data: body.data,
        esito: body.esito,
        tecnico: body.tecnico,
        cliente: body.cliente,
        modello: body.modello,
        matricola: body.matricola,
        n_bolla: body.n_bolla || null,
        volt_vuoto: body.volt_vuoto,
        volt_scarica: body.volt_scarica,
        densita_1: body.densita_1,
        densita_m: body.densita_m,
        created_at: body.created_at ? new Date(body.created_at) : new Date(),
      })
      .returning();
    res.status(201).json(record);
  } catch (err) {
    res.status(500).json({ error: "Errore nel salvataggio del record" });
  }
});

router.patch("/collaudo/:id/bolla", async (req, res) => {
  try {
    const { n_bolla } = req.body;
    const [record] = await db
      .update(collaudoRecords)
      .set({ n_bolla: n_bolla || null })
      .where(eq(collaudoRecords.id, req.params.id))
      .returning();
    if (!record) {
      res.status(404).json({ error: "Record non trovato" });
      return;
    }
    res.json(record);
  } catch (err) {
    res.status(500).json({ error: "Errore nell'aggiornamento della bolla" });
  }
});

router.delete("/collaudo/:id", async (req, res) => {
  try {
    await db
      .delete(collaudoRecords)
      .where(eq(collaudoRecords.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: "Errore nell'eliminazione del record" });
  }
});

export default router;
