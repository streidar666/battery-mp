import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import collaudoRouter from "./collaudo";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(requireAuth);
router.use(collaudoRouter);

export default router;
