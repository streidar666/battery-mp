import { useState, useCallback } from "react";
import { Filter, X, RotateCcw, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { CollaudoFilters } from "@/types/collaudo";

interface Props {
  filters: CollaudoFilters;
  onChange: (filters: CollaudoFilters) => void;
  tecnici: string[];
  clienti: string[];
  filteredCount: number;
  totalCount: number;
}

const defaultFilters: CollaudoFilters = {
  esito: "all",
  tecnico: [],
  cliente: [],
  dataFrom: "",
  dataTo: "",
  search: "",
};

function MultiSelect({
  label,
  options,
  selected,
  onChange,
}: {
  label: string;
  options: string[];
  selected: string[];
  onChange: (val: string[]) => void;
}) {
  const [open, setOpen] = useState(false);

  const toggle = (opt: string) => {
    if (selected.includes(opt)) {
      onChange(selected.filter((s) => s !== opt));
    } else {
      onChange([...selected, opt]);
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex items-center gap-1 h-8 px-3 text-xs rounded-md border transition-colors",
          selected.length > 0
            ? "border-primary/60 bg-primary/10 text-primary"
            : "border-border bg-card text-muted-foreground hover:border-border/80"
        )}
        data-testid={`multiselect-${label.toLowerCase()}`}
      >
        <Filter className="w-3 h-3" />
        {label}
        {selected.length > 0 && (
          <span className="ml-1 bg-primary text-primary-foreground rounded-full w-4 h-4 text-[10px] flex items-center justify-center font-bold">
            {selected.length}
          </span>
        )}
        {open ? <ChevronUp className="w-3 h-3 ml-1" /> : <ChevronDown className="w-3 h-3 ml-1" />}
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 z-50 min-w-40 bg-popover border border-border rounded-md shadow-lg py-1 max-h-48 overflow-y-auto">
          {options.length === 0 ? (
            <p className="px-3 py-2 text-xs text-muted-foreground">Nessuna opzione</p>
          ) : (
            options.map((opt) => (
              <button
                key={opt}
                type="button"
                onClick={() => toggle(opt)}
                className={cn(
                  "w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-accent transition-colors",
                  selected.includes(opt) ? "text-primary font-medium" : "text-foreground"
                )}
                data-testid={`option-${label.toLowerCase()}-${opt}`}
              >
                <span
                  className={cn(
                    "w-3 h-3 rounded-sm border flex-shrink-0",
                    selected.includes(opt) ? "bg-primary border-primary" : "border-border"
                  )}
                />
                {opt}
              </button>
            ))
          )}
          {selected.length > 0 && (
            <div className="border-t border-border mt-1 pt-1">
              <button
                type="button"
                onClick={() => onChange([])}
                className="w-full text-left px-3 py-1 text-xs text-muted-foreground hover:text-foreground"
              >
                Deseleziona tutti
              </button>
            </div>
          )}
        </div>
      )}

      {open && (
        <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
      )}
    </div>
  );
}

function ActiveFilterPill({
  label,
  onRemove,
}: {
  label: string;
  onRemove: () => void;
}) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/15 text-primary border border-primary/30 rounded-full text-xs font-medium">
      {label}
      <button
        type="button"
        onClick={onRemove}
        className="hover:text-red-400 transition-colors"
        data-testid="remove-filter"
      >
        <X className="w-3 h-3" />
      </button>
    </span>
  );
}

export function AdvancedFilters({ filters, onChange, tecnici, clienti, filteredCount, totalCount }: Props) {
  const [collapsed, setCollapsed] = useState(false);

  const update = useCallback(
    (partial: Partial<CollaudoFilters>) => {
      onChange({ ...filters, ...partial });
    },
    [filters, onChange]
  );

  const reset = useCallback(() => onChange({ ...defaultFilters }), [onChange]);

  const hasActiveFilters =
    (filters.esito && filters.esito !== "all") ||
    filters.tecnico.length > 0 ||
    filters.cliente.length > 0 ||
    !!filters.dataFrom ||
    !!filters.dataTo ||
    !!filters.search;

  const inputClass = "h-8 text-xs bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary/30";

  return (
    <div className="border border-border rounded-lg bg-card/50 no-print">
      <div
        className="flex items-center justify-between px-3 py-2 cursor-pointer select-none"
        onClick={() => setCollapsed((c) => !c)}
        data-testid="filters-toggle"
      >
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-primary" />
          <span className="text-xs font-semibold text-foreground">Filtri Avanzati</span>
          {hasActiveFilters && (
            <span className="px-1.5 py-0.5 bg-primary/20 text-primary rounded text-[10px] font-bold">
              ATTIVI
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {filteredCount} / {totalCount} record
          </span>
          {collapsed ? (
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          ) : (
            <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" />
          )}
        </div>
      </div>

      {!collapsed && (
        <div className="px-3 pb-3 space-y-2 border-t border-border">
          <div className="flex flex-wrap gap-2 pt-2 items-end">
            <div>
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Esito</Label>
              <Select
                value={filters.esito || "all"}
                onValueChange={(v) => update({ esito: v })}
              >
                <SelectTrigger className={cn(inputClass, "w-28")} data-testid="filter-esito">
                  <SelectValue placeholder="Tutti" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti</SelectItem>
                  <SelectItem value="Idonea">
                    <span className="text-green-400">Idonea</span>
                  </SelectItem>
                  <SelectItem value="Scarto">
                    <span className="text-red-400">Scarto</span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Tecnico</Label>
              <MultiSelect
                label="Tecnico"
                options={tecnici}
                selected={filters.tecnico}
                onChange={(v) => update({ tecnico: v })}
              />
            </div>

            <div>
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Cliente</Label>
              <MultiSelect
                label="Cliente"
                options={clienti}
                selected={filters.cliente}
                onChange={(v) => update({ cliente: v })}
              />
            </div>

            <div>
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Da</Label>
              <Input
                type="date"
                value={filters.dataFrom}
                onChange={(e) => update({ dataFrom: e.target.value })}
                className={cn(inputClass, "w-36")}
                data-testid="filter-data-from"
              />
            </div>

            <div>
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">A</Label>
              <Input
                type="date"
                value={filters.dataTo}
                onChange={(e) => update({ dataTo: e.target.value })}
                className={cn(inputClass, "w-36")}
                data-testid="filter-data-to"
              />
            </div>

            <div className="flex-1 min-w-36">
              <Label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Ricerca libera</Label>
              <Input
                type="search"
                value={filters.search}
                onChange={(e) => update({ search: e.target.value })}
                placeholder="Cerca matricola, cliente..."
                className={inputClass}
                data-testid="filter-search"
              />
            </div>

            {hasActiveFilters && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={reset}
                className="h-8 text-xs gap-1.5 border-red-500/40 text-red-400 hover:bg-red-500/10 hover:border-red-500/60"
                data-testid="button-reset-filters"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </Button>
            )}
          </div>

          {hasActiveFilters && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {filters.esito && filters.esito !== "all" && (
                <ActiveFilterPill
                  label={`Esito: ${filters.esito}`}
                  onRemove={() => update({ esito: "all" })}
                />
              )}
              {filters.tecnico.map((t) => (
                <ActiveFilterPill
                  key={t}
                  label={`Tecnico: ${t}`}
                  onRemove={() => update({ tecnico: filters.tecnico.filter((x) => x !== t) })}
                />
              ))}
              {filters.cliente.map((c) => (
                <ActiveFilterPill
                  key={c}
                  label={`Cliente: ${c}`}
                  onRemove={() => update({ cliente: filters.cliente.filter((x) => x !== c) })}
                />
              ))}
              {filters.dataFrom && (
                <ActiveFilterPill
                  label={`Da: ${filters.dataFrom}`}
                  onRemove={() => update({ dataFrom: "" })}
                />
              )}
              {filters.dataTo && (
                <ActiveFilterPill
                  label={`A: ${filters.dataTo}`}
                  onRemove={() => update({ dataTo: "" })}
                />
              )}
              {filters.search && (
                <ActiveFilterPill
                  label={`Cerca: ${filters.search}`}
                  onRemove={() => update({ search: "" })}
                />
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
