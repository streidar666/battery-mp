import { useState, useCallback, useRef } from "react";
import { Plus, Check, X, Zap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  validateMatricola,
  validateVolt,
  validateDensita,
  validateData,
  validateRequired,
  isFormValid,
} from "@/lib/validation";
import type { ValidationResult } from "@/types/collaudo";
import { cn } from "@/lib/utils";

interface FormData {
  data: string;
  esito: string;
  tecnico: string;
  cliente: string;
  modello: string;
  matricola: string;
  n_bolla: string;
  volt_vuoto: string;
  volt_scarica: string;
  densita_1: string;
  densita_m: string;
}

interface Props {
  onSave: (data: FormData) => void | Promise<void>;
  knownTecnici?: string[];
  knownClienti?: string[];
  knownModelli?: string[];
}

const defaultForm: FormData = {
  data: new Date().toISOString().split("T")[0],
  esito: "Idonea",
  tecnico: "",
  cliente: "",
  modello: "",
  matricola: "",
  n_bolla: "",
  volt_vuoto: "",
  volt_scarica: "",
  densita_1: "",
  densita_m: "",
};

function FieldStatus({ result, touched }: { result: ValidationResult; touched: boolean }) {
  return (
    <span
      className={cn(
        "ml-1 text-xs font-medium inline-block w-4",
        !touched ? "invisible" : result.valid ? "text-green-400" : "text-red-400"
      )}
      title={touched ? (result.valid ? "OK" : result.message) : ""}
    >
      {touched && result.valid ? <Check className="inline w-3.5 h-3.5" /> : <X className="inline w-3.5 h-3.5" />}
    </span>
  );
}

function FieldError(_props: { result: ValidationResult; touched: boolean }) {
  return null;
}

function SuggestionDropdown({
  suggestions,
  value,
  onSelect,
  inputRef,
}: {
  suggestions: string[];
  value: string;
  onSelect: (val: string) => void;
  inputRef: React.RefObject<HTMLInputElement>;
}) {
  const filtered = value.length > 0
    ? suggestions.filter((s) => s.toLowerCase().includes(value.toLowerCase()) && s.toLowerCase() !== value.toLowerCase())
    : [];
  if (filtered.length === 0) return null;
  return (
    <div className="absolute left-0 right-0 z-50 mt-1 bg-card border border-border rounded-md shadow-lg max-h-32 overflow-y-auto" style={{ position: "absolute", top: "100%" }}>
      {filtered.slice(0, 6).map((s) => (
        <button
          key={s}
          type="button"
          className="w-full text-left px-3 py-1.5 text-sm text-foreground hover:bg-accent/50 transition-colors"
          onMouseDown={(e) => {
            e.preventDefault();
            onSelect(s);
            inputRef.current?.focus();
          }}
        >
          {s}
        </button>
      ))}
    </div>
  );
}

export function CollaudoForm({ onSave, knownTecnici = [], knownClienti = [], knownModelli = [] }: Props) {
  const [form, setForm] = useState<FormData>(defaultForm);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const dataRef = useRef<HTMLInputElement>(null);
  const tecnicoRef = useRef<HTMLInputElement>(null);
  const clienteRef = useRef<HTMLInputElement>(null);
  const modelloRef = useRef<HTMLInputElement>(null);
  const matricolaRef = useRef<HTMLInputElement>(null);
  const nBollaRef = useRef<HTMLInputElement>(null);
  const voltVuotoRef = useRef<HTMLInputElement>(null);
  const voltScaricaRef = useRef<HTMLInputElement>(null);
  const densita1Ref = useRef<HTMLInputElement>(null);
  const densitaMRef = useRef<HTMLInputElement>(null);

  const fieldOrder = [
    dataRef,
    tecnicoRef,
    clienteRef,
    nBollaRef,
    modelloRef,
    matricolaRef,
    voltVuotoRef,
    voltScaricaRef,
    densita1Ref,
    densitaMRef,
  ];

  const validations: Record<string, ValidationResult> = {
    data: validateData(form.data),
    tecnico: validateRequired(form.tecnico, "Tecnico"),
    cliente: validateRequired(form.cliente, "Cliente"),
    modello: validateRequired(form.modello, "Tipo Batteria"),
    matricola: validateMatricola(form.matricola),
    volt_vuoto: validateVolt(form.volt_vuoto, "Tensione a Vuoto"),
    volt_scarica: validateVolt(form.volt_scarica, "Tensione di Scarica"),
    densita_1: validateDensita(form.densita_1, "Densità 1° Elemento"),
    densita_m: validateDensita(form.densita_m, "Densità di Mezzo"),
  };

  const formValid = isFormValid(validations);

  const touch = useCallback((field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  }, []);

  const handleChange = useCallback(
    (field: keyof FormData, value: string) => {
      if (field === "modello") {
        setForm((prev) => {
          const old = prev.modello;
          if (
            value.length === 2 &&
            old.length === 1 &&
            /^\d{2}$/.test(value)
          ) {
            return { ...prev, modello: value + " X " };
          }
          return { ...prev, modello: value };
        });
      } else {
        setForm((prev) => ({ ...prev, [field]: value }));
      }
      touch(field);
    },
    [touch]
  );

  const executeSaveAndNext = () => {
    const allTouched = Object.keys(validations).reduce(
      (acc, k) => ({ ...acc, [k]: true }),
      {}
    );
    setTouched(allTouched);
    if (!formValid) return;
    onSave({ ...form });
    setForm((prev) => ({
      ...prev,
      matricola: "",
      volt_vuoto: "",
      volt_scarica: "",
      densita_1: "",
      densita_m: "",
    }));
    setTouched({});
    setTimeout(() => matricolaRef.current?.focus(), 50);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const allTouched = Object.keys(validations).reduce(
      (acc, k) => ({ ...acc, [k]: true }),
      {}
    );
    setTouched(allTouched);
    if (!formValid) return;
    onSave({ ...form });
    setForm({ ...defaultForm, data: form.data, tecnico: form.tecnico });
    setTouched({});
  };

  const handleSaveAndNext = (e: React.MouseEvent) => {
    e.preventDefault();
    executeSaveAndNext();
  };

  const handleEnterKey = (
    e: React.KeyboardEvent<HTMLInputElement>,
    currentRef: React.RefObject<HTMLInputElement>
  ) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const idx = fieldOrder.indexOf(currentRef);
    if (idx === fieldOrder.length - 1) {
      executeSaveAndNext();
    } else if (idx >= 0) {
      fieldOrder[idx + 1].current?.focus();
    }
  };

  const inputClass =
    "bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-0 h-8 text-sm w-full";

  const fieldCell = "flex flex-col gap-1";
  const labelClass = "text-xs text-muted-foreground flex items-center gap-1 h-4 leading-4";

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-3"
      autoComplete="off"
      data-testid="form-collaudo"
    >
      <fieldset className="space-y-3 border border-border/40 rounded-md p-3">
        <legend className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-1">Informazioni</legend>
        <div className="grid grid-cols-2 gap-x-3 gap-y-3">
          <div className={fieldCell}>
            <Label htmlFor="data" className={labelClass}>Data</Label>
            <Input id="data" ref={dataRef} type="date" autoComplete="off" value={form.data} onChange={(e) => handleChange("data", e.target.value)} onKeyDown={(e) => handleEnterKey(e, dataRef)} className={inputClass} data-testid="input-data" />
          </div>
          <div className={fieldCell}>
            <Label htmlFor="esito" className={labelClass}>Esito</Label>
            <Select value={form.esito} onValueChange={(v) => handleChange("esito", v)}>
              <SelectTrigger className={cn(inputClass)} data-testid="select-esito"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Idonea"><span className="text-green-400 font-medium">Idonea</span></SelectItem>
                <SelectItem value="Scarto"><span className="text-red-400 font-medium">Scarto</span></SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className={fieldCell}>
            <Label htmlFor="tecnico" className={labelClass}>Tecnico <FieldStatus result={validations.tecnico} touched={!!touched.tecnico} /></Label>
            <div className="relative">
              <Input id="tecnico" ref={tecnicoRef} autoComplete="off" value={form.tecnico} onChange={(e) => handleChange("tecnico", e.target.value)} onFocus={() => setFocusedField("tecnico")} onBlur={() => setFocusedField(null)} onKeyDown={(e) => handleEnterKey(e, tecnicoRef)} placeholder="Nome tecnico" className={inputClass} data-testid="input-tecnico" />
              {focusedField === "tecnico" && <SuggestionDropdown suggestions={knownTecnici} value={form.tecnico} onSelect={(val) => handleChange("tecnico", val)} inputRef={tecnicoRef} />}
            </div>
          </div>
          <div className={fieldCell}>
            <Label htmlFor="cliente" className={labelClass}>Cliente <FieldStatus result={validations.cliente} touched={!!touched.cliente} /></Label>
            <div className="relative">
              <Input id="cliente" ref={clienteRef} autoComplete="off" value={form.cliente} onChange={(e) => handleChange("cliente", e.target.value)} onFocus={() => setFocusedField("cliente")} onBlur={() => setFocusedField(null)} onKeyDown={(e) => handleEnterKey(e, clienteRef)} placeholder="Nome cliente" className={inputClass} data-testid="input-cliente" />
              {focusedField === "cliente" && <SuggestionDropdown suggestions={knownClienti} value={form.cliente} onSelect={(val) => handleChange("cliente", val)} inputRef={clienteRef} />}
            </div>
          </div>
          <div className={cn(fieldCell, "col-span-2")}>
            <Label htmlFor="n_bolla" className={labelClass}>N. Bolla <span className="text-muted-foreground/50 font-normal">(facoltativo)</span></Label>
            <Input id="n_bolla" ref={nBollaRef} autoComplete="off" value={form.n_bolla} onChange={(e) => handleChange("n_bolla", e.target.value)} onKeyDown={(e) => handleEnterKey(e, nBollaRef)} placeholder="N. Bolla" className={inputClass} data-testid="input-n-bolla" />
          </div>
        </div>
      </fieldset>

      <fieldset className="space-y-3 border border-border/40 rounded-md p-3">
        <legend className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-1">Batteria</legend>
        <div className="grid grid-cols-2 gap-x-3 gap-y-3">
          <div className={fieldCell}>
            <Label htmlFor="modello" className={labelClass}>Tipo Batteria <FieldStatus result={validations.modello} touched={!!touched.modello} /></Label>
            <div className="relative">
              <Input id="modello" ref={modelloRef} autoComplete="off" value={form.modello} onChange={(e) => handleChange("modello", e.target.value)} onFocus={() => setFocusedField("modello")} onBlur={() => setFocusedField(null)} onKeyDown={(e) => handleEnterKey(e, modelloRef)} placeholder="Es. 4 HPZS 500" className={inputClass} data-testid="input-modello" />
              {focusedField === "modello" && <SuggestionDropdown suggestions={knownModelli} value={form.modello} onSelect={(val) => handleChange("modello", val)} inputRef={modelloRef} />}
            </div>
          </div>
          <div className={fieldCell}>
            <Label htmlFor="matricola" className={labelClass}>Matricola <FieldStatus result={validations.matricola} touched={!!touched.matricola} /></Label>
            <Input id="matricola" ref={matricolaRef} autoComplete="off" value={form.matricola} onChange={(e) => handleChange("matricola", e.target.value)} onKeyDown={(e) => handleEnterKey(e, matricolaRef)} placeholder="Es. 25004/1" className={inputClass} data-testid="input-matricola" />
          </div>
        </div>
      </fieldset>

      <fieldset className="space-y-3 border border-border/40 rounded-md p-3">
        <legend className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-1">Misure</legend>
        <div className="grid grid-cols-2 gap-x-3 gap-y-3">
          <div className={fieldCell}>
            <Label htmlFor="volt_vuoto" className={labelClass}>Tens. a Vuoto <FieldStatus result={validations.volt_vuoto} touched={!!touched.volt_vuoto} /></Label>
            <Input id="volt_vuoto" ref={voltVuotoRef} type="number" step="0.01" autoComplete="off" value={form.volt_vuoto} onChange={(e) => handleChange("volt_vuoto", e.target.value)} onKeyDown={(e) => handleEnterKey(e, voltVuotoRef)} placeholder="Es. 50" className={inputClass} data-testid="input-volt-vuoto" />
          </div>
          <div className={fieldCell}>
            <Label htmlFor="volt_scarica" className={labelClass}>Tens. di Scarica <FieldStatus result={validations.volt_scarica} touched={!!touched.volt_scarica} /></Label>
            <Input id="volt_scarica" ref={voltScaricaRef} type="number" step="0.01" autoComplete="off" value={form.volt_scarica} onChange={(e) => handleChange("volt_scarica", e.target.value)} onKeyDown={(e) => handleEnterKey(e, voltScaricaRef)} placeholder="Es. 41.2" className={inputClass} data-testid="input-volt-scarica" />
          </div>
          <div className={fieldCell}>
            <Label htmlFor="densita_1" className={labelClass}>Densità 1° Elem. <FieldStatus result={validations.densita_1} touched={!!touched.densita_1} /></Label>
            <Input id="densita_1" ref={densita1Ref} type="number" step="0.001" min="1.0" max="1.4" autoComplete="off" value={form.densita_1} onChange={(e) => handleChange("densita_1", e.target.value)} onKeyDown={(e) => handleEnterKey(e, densita1Ref)} placeholder="Es. 1.27" className={inputClass} data-testid="input-densita-1" />
          </div>
          <div className={fieldCell}>
            <Label htmlFor="densita_m" className={labelClass}>Densità di Mezzo <FieldStatus result={validations.densita_m} touched={!!touched.densita_m} /></Label>
            <Input id="densita_m" ref={densitaMRef} type="number" step="0.001" min="1.0" max="1.4" autoComplete="off" value={form.densita_m} onChange={(e) => handleChange("densita_m", e.target.value)} onKeyDown={(e) => handleEnterKey(e, densitaMRef)} placeholder="Es. 1.28" className={inputClass} data-testid="input-densita-m" />
          </div>
        </div>
      </fieldset>

      <div className="grid grid-cols-2 gap-3 pt-1">
        <Button
          type="submit"
          className={cn(
            "w-full h-9 font-semibold text-sm gap-2 transition-all",
            formValid
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-muted text-muted-foreground cursor-not-allowed opacity-60"
          )}
          data-testid="button-save"
        >
          <Plus className="w-4 h-4" />
          Salva
        </Button>

        <Button
          type="button"
          onClick={handleSaveAndNext}
          className={cn(
            "w-full h-9 font-semibold text-sm gap-2 transition-all border",
            formValid
              ? "bg-background border-primary text-primary hover:bg-primary/10"
              : "bg-muted border-muted text-muted-foreground cursor-not-allowed opacity-60"
          )}
          data-testid="button-save-next"
        >
          <ArrowRight className="w-4 h-4" />
          Salva & Prossima
        </Button>
      </div>
    </form>
  );
}
