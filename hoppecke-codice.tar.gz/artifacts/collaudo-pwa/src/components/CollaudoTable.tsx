import { useState, useRef, useEffect } from "react";
import { Trash2, ChevronUp, ChevronDown, ChevronsUpDown, FileSpreadsheet, FileText, Pencil, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import type { CollaudoRecord } from "@/types/collaudo";
import { exportRecordToCSV, exportRecordToPDF } from "@/lib/stats";

type SortKey = keyof CollaudoRecord;
type SortDir = "asc" | "desc";

interface Props {
  records: CollaudoRecord[];
  onDelete: (id: string) => void;
  onUpdateBolla: (id: string, n_bolla: string) => void;
}

function SortIcon({ field, sortKey, sortDir }: { field: SortKey; sortKey: SortKey | null; sortDir: SortDir }) {
  if (sortKey !== field) return <ChevronsUpDown className="w-3 h-3 opacity-30" />;
  return sortDir === "asc" ? (
    <ChevronUp className="w-3 h-3 text-primary" />
  ) : (
    <ChevronDown className="w-3 h-3 text-primary" />
  );
}

function InlineBollaEdit({ value, onSave, onCancel }: { value: string; onSave: (v: string) => void; onCancel: () => void }) {
  const [draft, setDraft] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { e.preventDefault(); onSave(draft); }
    if (e.key === "Escape") { e.preventDefault(); onCancel(); }
  };

  return (
    <div className="flex items-center gap-1">
      <input
        ref={inputRef}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={handleKeyDown}
        className="bg-card border border-primary/50 rounded px-1 py-0.5 text-[11px] font-mono w-20 text-foreground focus:outline-none focus:border-primary"
      />
      <button onClick={() => onSave(draft)} className="text-green-400 hover:text-green-300" title="Conferma">
        <Check className="w-3 h-3" />
      </button>
      <button onClick={onCancel} className="text-red-400 hover:text-red-300" title="Annulla">
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}

export function CollaudoTable({ records, onDelete, onUpdateBolla }: Props) {
  const [sortKey, setSortKey] = useState<SortKey | null>("data");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [editingBollaId, setEditingBollaId] = useState<string | null>(null);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const sorted = [...records].sort((a, b) => {
    if (!sortKey) return 0;
    const av = a[sortKey] ?? "";
    const bv = b[sortKey] ?? "";
    const cmp = String(av).localeCompare(String(bv), undefined, { numeric: true });
    return sortDir === "asc" ? cmp : -cmp;
  });

  const columns: { key: SortKey; label: string }[] = [
    { key: "data", label: "Data" },
    { key: "esito", label: "Esito" },
    { key: "tecnico", label: "Tecnico" },
    { key: "cliente", label: "Cliente" },
    { key: "modello", label: "Tipo Batteria" },
    { key: "matricola", label: "Matricola" },
    { key: "n_bolla", label: "N. Bolla" },
    { key: "volt_vuoto", label: "T. Vuoto" },
    { key: "volt_scarica", label: "T. Scarica" },
    { key: "densita_1", label: "Dens. 1°" },
    { key: "densita_m", label: "Dens. ½" },
  ];

  const thClass =
    "px-3 py-2 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wider select-none cursor-pointer hover:text-foreground transition-colors";
  const tdClass = "px-3 py-2 text-[12px] text-foreground/90";

  const handleBollaSave = (id: string, newVal: string) => {
    onUpdateBolla(id, newVal);
    setEditingBollaId(null);
  };

  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card/50 shadow-lg">
      <table className="w-full text-sm" id="collaudo-table">
        <thead>
          <tr className="border-b border-border bg-card/80">
            {columns.map((col) => (
              <th key={col.key} className={thClass} onClick={() => handleSort(col.key)}>
                <div className="flex items-center gap-1">
                  {col.label}
                  <SortIcon field={col.key} sortKey={sortKey} sortDir={sortDir} />
                </div>
              </th>
            ))}
            <th className="px-3 py-2 no-print" style={{ width: "110px" }} />
          </tr>
        </thead>
        <tbody>
          {sorted.map((r, i) => (
            <tr
              key={r.id}
              className={cn(
                "border-b border-border/50 hover:bg-accent/30 transition-colors",
                i % 2 === 0 ? "bg-transparent" : "bg-card/30"
              )}
              data-testid={`row-record-${r.id}`}
            >
              <td className={tdClass}>{r.data}</td>
              <td className={tdClass}>
                <span
                  className={cn(
                    "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold",
                    r.esito === "Idonea"
                      ? "bg-green-500/15 text-green-400 border border-green-500/30"
                      : "bg-red-500/15 text-red-400 border border-red-500/30"
                  )}
                  data-testid={`badge-esito-${r.id}`}
                >
                  {r.esito}
                </span>
              </td>
              <td className={cn(tdClass, "whitespace-nowrap")}>{r.tecnico}</td>
              <td className={cn(tdClass, "whitespace-nowrap")}>{r.cliente}</td>
              <td className={tdClass}>{r.modello}</td>
              <td className={cn(tdClass, "font-mono text-[11px]")}>{r.matricola}</td>
              <td className={cn(tdClass, "font-mono text-[11px]")}>
                {editingBollaId === r.id ? (
                  <InlineBollaEdit
                    value={r.n_bolla || ""}
                    onSave={(v) => handleBollaSave(r.id, v)}
                    onCancel={() => setEditingBollaId(null)}
                  />
                ) : (
                  <div className="flex items-center gap-1 group">
                    <span>{r.n_bolla || "—"}</span>
                    <button
                      onClick={() => setEditingBollaId(r.id)}
                      className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-yellow-400 transition-opacity"
                      title="Modifica N. Bolla"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </td>
              <td className={cn(tdClass, "text-right font-mono text-[11px]")}>{r.volt_vuoto}V</td>
              <td className={cn(tdClass, "text-right font-mono text-[11px]")}>{r.volt_scarica}V</td>
              <td className={cn(tdClass, "text-right font-mono text-[11px]")}>{r.densita_1}</td>
              <td className={cn(tdClass, "text-right font-mono text-[11px]")}>{r.densita_m}</td>
              <td className="px-2 py-2 no-print">
                <div className="flex items-center gap-0.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-muted-foreground hover:text-green-400 hover:bg-green-500/10"
                    title="Esporta Excel"
                    onClick={() => exportRecordToCSV(r)}
                    data-testid={`button-csv-${r.id}`}
                  >
                    <FileSpreadsheet className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10"
                    title="Esporta PDF"
                    onClick={() => exportRecordToPDF(r)}
                    data-testid={`button-pdf-${r.id}`}
                  >
                    <FileText className="w-3 h-3" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 text-muted-foreground hover:text-red-400 hover:bg-red-500/10"
                        data-testid={`button-delete-${r.id}`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-border">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Elimina record</AlertDialogTitle>
                        <AlertDialogDescription className="text-muted-foreground">
                          Stai per eliminare il collaudo della matricola <strong>{r.matricola}</strong> del {r.data}. Questa azione non è reversibile.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="border-border">Annulla</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(r.id)}
                          className="bg-red-500 hover:bg-red-600 text-white"
                          data-testid={`confirm-delete-${r.id}`}
                        >
                          Elimina
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
