interface Props {
  className?: string;
  height?: number;
  variant?: "dark" | "light";
}

export function HoppeckeLogo({ className = "", height = 28, variant = "dark" }: Props) {
  const textColor = variant === "dark" ? "#1a5c2a" : "#1a5c2a";

  return (
    <svg
      viewBox="0 0 220 36"
      height={height}
      className={className}
      role="img"
      aria-label="HOPPECKE Logo"
    >
      <text
        x="0"
        y="28"
        fontFamily="Arial Black, Arial, Helvetica, sans-serif"
        fontWeight="900"
        fontSize="32"
        letterSpacing="2"
        fill={textColor}
      >
        HOPPECKE
      </text>
    </svg>
  );
}
