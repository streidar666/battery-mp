import { TrendingUp, TrendingDown, Building2, AlertTriangle, BarChart3 } from "lucide-react";
import type { CollaudoStats } from "@/types/collaudo";
import { cn } from "@/lib/utils";

interface Props {
  stats: CollaudoStats;
  collapsed?: boolean;
  onToggle?: () => void;
}

function BarSegment({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
      <div
        className={cn("h-full rounded-full transition-all duration-500", color)}
        style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
      />
    </div>
  );
}

function TrendBars({ trend }: { trend: { date: string; count: number }[] }) {
  const max = Math.max(...trend.map((t) => t.count), 1);
  return (
    <div className="flex items-end gap-1 h-8">
      {trend.map((t) => {
        const heightPct = max > 0 ? (t.count / max) * 100 : 0;
        const label = t.date.slice(5);
        return (
          <div
            key={t.date}
            className="flex-1 flex flex-col items-center gap-0.5"
            title={`${label}: ${t.count} collaudi`}
          >
            <div className="w-full flex items-end" style={{ height: "28px" }}>
              <div
                className="w-full bg-primary/60 rounded-t transition-all duration-500"
                style={{ height: `${Math.max(4, heightPct)}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function StatsPanel({ stats }: Props) {
  const scartColor =
    stats.scartRate < 5
      ? "text-green-400"
      : stats.scartRate < 10
      ? "text-yellow-400"
      : "text-red-400";

  const scartBgBar =
    stats.scartRate < 5
      ? "bg-green-500"
      : stats.scartRate < 10
      ? "bg-yellow-500"
      : "bg-red-500";

  const idoneePercent = stats.total > 0 ? (stats.idonee / stats.total) * 100 : 0;
  const scartiPercent = stats.total > 0 ? (stats.scarti / stats.total) * 100 : 0;

  const totalTrend = stats.trend7d.reduce((s, t) => s + t.count, 0);
  const prevHalf = stats.trend7d.slice(0, 3).reduce((s, t) => s + t.count, 0);
  const lastHalf = stats.trend7d.slice(4).reduce((s, t) => s + t.count, 0);
  const trendUp = lastHalf >= prevHalf;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 no-print">
      <div className="col-span-2 bg-card border border-border rounded-lg p-3 space-y-2">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-3.5 h-3.5 text-primary" />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Esiti
          </span>
          <span className="ml-auto text-xs font-bold text-foreground">{stats.total} tot.</span>
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-xs text-green-400 w-16 flex-shrink-0">Idonee</span>
            <BarSegment pct={idoneePercent} color="bg-green-500" />
            <span className="text-xs font-semibold text-green-400 w-12 text-right">
              {stats.idonee} <span className="text-[10px] opacity-70">({idoneePercent.toFixed(0)}%)</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-red-400 w-16 flex-shrink-0">Scarti</span>
            <BarSegment pct={scartiPercent} color="bg-red-500" />
            <span className="text-xs font-semibold text-red-400 w-12 text-right">
              {stats.scarti} <span className="text-[10px] opacity-70">({scartiPercent.toFixed(0)}%)</span>
            </span>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-3 space-y-1.5">
        <div className="flex items-center gap-1.5">
          <AlertTriangle className={cn("w-3.5 h-3.5", scartColor)} />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Scarto Rate
          </span>
        </div>
        <div className={cn("text-2xl font-bold", scartColor)}>
          {stats.scartRate.toFixed(1)}%
        </div>
        <BarSegment pct={stats.scartRate * 10} color={scartBgBar} />
        <p className="text-[10px] text-muted-foreground">
          {stats.scartRate < 5 ? "Ottimo" : stats.scartRate < 10 ? "Attenzione" : "Critico"}
        </p>
      </div>

      <div className="bg-card border border-border rounded-lg p-3 space-y-1.5">
        <div className="flex items-center gap-1.5">
          {trendUp ? (
            <TrendingUp className="w-3.5 h-3.5 text-green-400" />
          ) : (
            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
          )}
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Ultimi 7 gg
          </span>
        </div>
        <TrendBars trend={stats.trend7d} />
        <p className="text-[10px] text-muted-foreground">{totalTrend} collaudi</p>
      </div>

      {stats.topCliente && (
        <div className="bg-card border border-border rounded-lg p-3 space-y-1">
          <div className="flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-primary" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Top Cliente
            </span>
          </div>
          <p className="text-sm font-semibold text-foreground truncate">{stats.topCliente.name}</p>
          <p className="text-[10px] text-muted-foreground">{stats.topCliente.count} collaudi</p>
          <div className="space-y-0.5 mt-1">
            {stats.clienti.slice(0, 3).map((c) => (
              <div key={c.name} className="flex items-center gap-1.5">
                <div
                  className="h-1 bg-primary/50 rounded"
                  style={{ width: `${(c.count / stats.clienti[0].count) * 60}px` }}
                />
                <span className="text-[10px] text-muted-foreground truncate">{c.name.split(" ")[0]}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!stats.topCliente && (
        <div className="col-span-2 bg-card border border-border rounded-lg p-3 flex items-center justify-center">
          <p className="text-xs text-muted-foreground">Nessun dato disponibile</p>
        </div>
      )}
    </div>
  );
}
