import type { CollaudoRecord } from "@/types/collaudo";
import { getToken, clearAuth } from "./auth";

const BASE = "/api";

async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getToken();
  const res = await fetch(url, {
    ...options,
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers ?? {}),
    },
  });
  if (res.status === 401) {
    clearAuth();
    window.location.reload();
  }
  return res;
}

export async function apiLogin(username: string, password: string): Promise<{ token: string; username: string }> {
  const res = await fetch(`${BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Credenziali non valide");
  }
  return res.json();
}

function normalizeRecord(r: Record<string, unknown>): CollaudoRecord {
  return {
    id: String(r.id ?? ""),
    data: String(r.data ?? ""),
    esito: (r.esito === "Scarto" ? "Scarto" : "Idonea") as "Idonea" | "Scarto",
    tecnico: String(r.tecnico ?? ""),
    cliente: String(r.cliente ?? ""),
    modello: String(r.modello ?? ""),
    matricola: String(r.matricola ?? ""),
    n_bolla: String(r.n_bolla ?? ""),
    volt_vuoto: String(r.volt_vuoto ?? ""),
    volt_scarica: String(r.volt_scarica ?? ""),
    densita_1: String(r.densita_1 ?? ""),
    densita_m: String(r.densita_m ?? ""),
    created_at: String(r.created_at ?? new Date().toISOString()),
  };
}

export async function apiGetRecords(): Promise<CollaudoRecord[]> {
  let lastError: Error | null = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await authFetch(`${BASE}/collaudo`);
      if (!res.ok) throw new Error("Errore nel caricamento dei record");
      const rows = await res.json();
      return rows.map((r: Record<string, unknown>) => normalizeRecord(r));
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      if (attempt < 2) await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
    }
  }
  throw lastError!;
}

export async function apiAddRecord(record: CollaudoRecord): Promise<CollaudoRecord> {
  const res = await authFetch(`${BASE}/collaudo`, {
    method: "POST",
    body: JSON.stringify(record),
  });
  if (!res.ok) throw new Error("Errore nel salvataggio del record");
  return res.json();
}

export async function apiUpdateBolla(id: string, n_bolla: string): Promise<CollaudoRecord> {
  const res = await authFetch(`${BASE}/collaudo/${id}/bolla`, {
    method: "PATCH",
    body: JSON.stringify({ n_bolla }),
  });
  if (!res.ok) throw new Error("Errore nell'aggiornamento della bolla");
  return res.json();
}

export async function apiDeleteRecord(id: string): Promise<void> {
  const res = await authFetch(`${BASE}/collaudo/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Errore nell'eliminazione del record");
}
