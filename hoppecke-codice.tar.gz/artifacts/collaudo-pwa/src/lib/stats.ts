import * as XLSX from "xlsx";
import type { CollaudoRecord, CollaudoStats } from "@/types/collaudo";

export function computeStats(records: CollaudoRecord[]): CollaudoStats {
  const total = records.length;
  const idonee = records.filter((r) => r.esito === "Idonea").length;
  const scarti = total - idonee;
  const scartRate = total > 0 ? (scarti / total) * 100 : 0;

  const tecnicoCount: Record<string, number> = {};
  const clienteCount: Record<string, number> = {};

  for (const r of records) {
    if (r.tecnico) tecnicoCount[r.tecnico] = (tecnicoCount[r.tecnico] || 0) + 1;
    if (r.cliente) clienteCount[r.cliente] = (clienteCount[r.cliente] || 0) + 1;
  }

  const tecnici = Object.entries(tecnicoCount)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const clienti = Object.entries(clienteCount)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const topTecnico = tecnici.length > 0 ? tecnici[0] : null;
  const topCliente = clienti.length > 0 ? clienti[0] : null;

  const today = new Date();
  const trend7d: { date: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split("T")[0];
    const count = records.filter((r) => r.data === dateStr).length;
    trend7d.push({ date: dateStr, count });
  }

  return {
    total,
    idonee,
    scarti,
    scartRate,
    topTecnico,
    topCliente,
    trend7d,
    tecnici,
    clienti,
  };
}

export function filterRecords(
  records: CollaudoRecord[],
  filters: {
    esito: string;
    tecnico: string[];
    cliente: string[];
    dataFrom: string;
    dataTo: string;
    search: string;
  }
): CollaudoRecord[] {
  return records.filter((r) => {
    if (filters.esito && filters.esito !== "all" && r.esito !== filters.esito) return false;
    if (filters.tecnico.length > 0 && !filters.tecnico.includes(r.tecnico)) return false;
    if (filters.cliente.length > 0 && !filters.cliente.includes(r.cliente)) return false;
    if (filters.dataFrom && r.data < filters.dataFrom) return false;
    if (filters.dataTo && r.data > filters.dataTo) return false;
    if (filters.search) {
      const s = filters.search.toLowerCase();
      const searchable = [r.tecnico, r.cliente, r.modello, r.matricola, r.n_bolla, r.esito]
        .join(" ")
        .toLowerCase();
      if (!searchable.includes(s)) return false;
    }
    return true;
  });
}

export function exportToCSV(records: CollaudoRecord[]): void {
  const stats = computeStats(records);
  const dateStr = new Date().toISOString().split("T")[0];

  const wb = XLSX.utils.book_new();

  /* ── FOGLIO 1: Dati Collaudi ── */
  const wsData: (string | number)[][] = [];

  wsData.push(["DATABASE HOPPECKE BATTERY CHECK"]);
  wsData.push([`Report generato il: ${new Date().toLocaleString("it-IT")}`]);
  wsData.push([]);
  wsData.push(["RIEPILOGO STATISTICHE"]);
  wsData.push(["Totale collaudi", stats.total]);
  wsData.push(["Idonee", stats.idonee, `${((stats.idonee / stats.total) * 100 || 0).toFixed(1)}%`]);
  wsData.push(["Scarti", stats.scarti, `${((stats.scarti / stats.total) * 100 || 0).toFixed(1)}%`]);
  wsData.push(["Scarto Rate", `${stats.scartRate.toFixed(1)}%`]);
  if (stats.topCliente) wsData.push(["Top Cliente", stats.topCliente.name, `${stats.topCliente.count} collaudi`]);
  wsData.push([]);
  wsData.push(["ELENCO COLLAUDI"]);
  wsData.push([
    "Data",
    "Esito",
    "Tecnico",
    "Cliente",
    "Tipo Batteria",
    "Matricola",
    "N. Bolla",
    "Tensione a Vuoto (V)",
    "Tensione di Scarica (V)",
    "Densità 1° Elemento (kg/l)",
    "Densità di Mezzo (kg/l)",
  ]);

  for (const r of records) {
    wsData.push([
      r.data,
      r.esito,
      r.tecnico,
      r.cliente,
      r.modello,
      r.matricola,
      r.n_bolla,
      parseFloat(r.volt_vuoto) || r.volt_vuoto,
      parseFloat(r.volt_scarica) || r.volt_scarica,
      parseFloat(r.densita_1) || r.densita_1,
      parseFloat(r.densita_m) || r.densita_m,
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(wsData);

  ws["!cols"] = [
    { wch: 12 },
    { wch: 10 },
    { wch: 18 },
    { wch: 18 },
    { wch: 14 },
    { wch: 14 },
    { wch: 14 },
    { wch: 15 },
    { wch: 16 },
    { wch: 17 },
    { wch: 20 },
  ];

  ws["!merges"] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 10 } },
  ];

  XLSX.utils.book_append_sheet(wb, ws, "Collaudi");

  /* ── FOGLIO 2: Statistiche Clienti ── */
  const wsStats: (string | number)[][] = [];
  wsStats.push(["STATISTICHE PER CLIENTE"]);
  wsStats.push([]);
  wsStats.push(["Cliente", "Totale Collaudi", "Idonee", "Scarti", "Scarto Rate %"]);
  for (const c of stats.clienti) {
    const clientRecords = records.filter((r) => r.cliente === c.name);
    const clientScarti = clientRecords.filter((r) => r.esito === "Scarto").length;
    const clientIdonee = clientRecords.filter((r) => r.esito === "Idonea").length;
    const clientRate = c.count > 0 ? ((clientScarti / c.count) * 100).toFixed(1) : "0.0";
    wsStats.push([c.name, c.count, clientIdonee, clientScarti, `${clientRate}%`]);
  }
  wsStats.push([]);
  wsStats.push(["STATISTICHE PER TECNICO"]);
  wsStats.push([]);
  wsStats.push(["Tecnico", "Totale Collaudi", "Idonee", "Scarti", "Scarto Rate %"]);
  for (const t of stats.tecnici) {
    const tRecords = records.filter((r) => r.tecnico === t.name);
    const tScarti = tRecords.filter((r) => r.esito === "Scarto").length;
    const tIdonee = tRecords.filter((r) => r.esito === "Idonea").length;
    const tRate = t.count > 0 ? ((tScarti / t.count) * 100).toFixed(1) : "0.0";
    wsStats.push([t.name, t.count, tIdonee, tScarti, `${tRate}%`]);
  }

  const wsStats2 = XLSX.utils.aoa_to_sheet(wsStats);
  wsStats2["!cols"] = [
    { wch: 22 },
    { wch: 16 },
    { wch: 12 },
    { wch: 10 },
    { wch: 14 },
  ];
  XLSX.utils.book_append_sheet(wb, wsStats2, "Statistiche");

  /* ── FOGLIO 3: Trend 7 giorni ── */
  const wsTrend: (string | number)[][] = [];
  wsTrend.push(["TREND ULTIMI 7 GIORNI"]);
  wsTrend.push([]);
  wsTrend.push(["Data", "N. Collaudi", "Idonee", "Scarti"]);
  for (const t of stats.trend7d) {
    const dayRecs = records.filter((r) => r.data === t.date);
    const dayIdonee = dayRecs.filter((r) => r.esito === "Idonea").length;
    const dayScarti = dayRecs.filter((r) => r.esito === "Scarto").length;
    wsTrend.push([t.date, t.count, dayIdonee, dayScarti]);
  }
  const wsT = XLSX.utils.aoa_to_sheet(wsTrend);
  wsT["!cols"] = [{ wch: 14 }, { wch: 14 }, { wch: 10 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, wsT, "Trend 7gg");

  XLSX.writeFile(wb, `hoppecke_battery_check_${dateStr}.xlsx`);
}

export function exportToExcel(records: CollaudoRecord[]): void {
  exportToCSV(records);
}

export function exportRecordToCSV(r: CollaudoRecord): void {
  const wb = XLSX.utils.book_new();
  const wsData: (string | number)[][] = [
    ["DATABASE HOPPECKE BATTERY CHECK — Collaudo singolo"],
    [],
    ["Campo", "Valore"],
    ["Data", r.data],
    ["Esito", r.esito],
    ["Tecnico", r.tecnico],
    ["Cliente", r.cliente],
    ["Tipo Batteria", r.modello],
    ["Matricola", r.matricola],
    ["N. Bolla", r.n_bolla],
    ["Tensione a Vuoto (V)", parseFloat(r.volt_vuoto) || r.volt_vuoto],
    ["Tensione di Scarica (V)", parseFloat(r.volt_scarica) || r.volt_scarica],
    ["Densità 1° Elemento (kg/l)", parseFloat(r.densita_1) || r.densita_1],
    ["Densità di Mezzo (kg/l)", parseFloat(r.densita_m) || r.densita_m],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  ws["!cols"] = [{ wch: 22 }, { wch: 24 }];
  XLSX.utils.book_append_sheet(wb, ws, "Collaudo");
  XLSX.writeFile(wb, `collaudo_${r.matricola}_${r.data}.xlsx`);
}

export function exportRecordToPDF(r: CollaudoRecord): void {
  const esitoColor = r.esito === "Idonea" ? "#22c55e" : "#ef4444";
  const esitoGlyph = r.esito === "Idonea" ? "✓" : "✗";
  const html = `<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8"/>
<title>Collaudo ${r.matricola} – ${r.data}</title>
<style>
  body{font-family:Arial,sans-serif;padding:32px;color:#111;max-width:600px;margin:0 auto}
  h1{font-size:16px;font-weight:700;margin:0 0 2px}
  .sub{color:#555;font-size:12px;margin:0 0 24px}
  .badge{display:inline-block;padding:4px 14px;border-radius:20px;font-weight:700;font-size:13px;color:#fff;background:${esitoColor};margin-bottom:24px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{text-align:left;background:#f4f4f4;padding:8px 10px;border-bottom:2px solid #ddd;width:50%}
  td{padding:8px 10px;border-bottom:1px solid #eee}
  tr:nth-child(even) td{background:#fafafa}
  .footer{margin-top:32px;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:12px}
  @media print{body{padding:16px}}
</style>
</head>
<body>
<h1>⚡ Database Hoppecke Battery Check</h1>
<p class="sub">Verbale di Collaudo — generato il ${new Date().toLocaleString("it-IT")}</p>
<div class="badge">${esitoGlyph} ${r.esito}</div>
<table>
  <tr><th>Data collaudo</th><td>${r.data}</td></tr>
  <tr><th>Tecnico</th><td>${r.tecnico}</td></tr>
  <tr><th>Cliente</th><td>${r.cliente}</td></tr>
  <tr><th>Tipo Batteria</th><td>${r.modello}</td></tr>
  <tr><th>Matricola</th><td><strong>${r.matricola}</strong></td></tr>
  <tr><th>N. Bolla</th><td>${r.n_bolla || "—"}</td></tr>
  <tr><th>Tensione a Vuoto</th><td>${r.volt_vuoto} V</td></tr>
  <tr><th>Tensione di Scarica</th><td>${r.volt_scarica} V</td></tr>
  <tr><th>Densità 1° Elemento</th><td>${r.densita_1} kg/l</td></tr>
  <tr><th>Densità di Mezzo</th><td>${r.densita_m} kg/l</td></tr>
</table>
<p class="footer">Database Hoppecke Battery Check — documento generato automaticamente</p>
</body>
</html>`;
  const w = window.open("", "_blank");
  if (!w) return;
  w.document.write(html);
  w.document.close();
  setTimeout(() => { w.print(); }, 300);
}
