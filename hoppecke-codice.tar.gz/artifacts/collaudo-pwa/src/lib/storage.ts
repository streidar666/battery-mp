import type { CollaudoRecord } from "@/types/collaudo";

const STORAGE_KEY = "hoppecke_battery_records_v2";

export function loadRecords(): CollaudoRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as CollaudoRecord[];
  } catch {
    return [];
  }
}

export function saveRecords(records: CollaudoRecord[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

export function addRecord(record: CollaudoRecord): CollaudoRecord[] {
  const records = loadRecords();
  const updated = [record, ...records];
  saveRecords(updated);
  return updated;
}

export function updateRecord(id: string, data: Partial<CollaudoRecord>): CollaudoRecord[] {
  const records = loadRecords();
  const updated = records.map((r) => (r.id === id ? { ...r, ...data } : r));
  saveRecords(updated);
  return updated;
}

export function deleteRecord(id: string): CollaudoRecord[] {
  const records = loadRecords();
  const updated = records.filter((r) => r.id !== id);
  saveRecords(updated);
  return updated;
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

