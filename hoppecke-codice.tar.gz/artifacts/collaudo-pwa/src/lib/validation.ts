import type { ValidationResult } from "@/types/collaudo";

export function validateMatricola(value: string): ValidationResult {
  if (!value || value.trim().length === 0) {
    return { valid: false, message: "La matricola è obbligatoria" };
  }
  if (value.trim().length < 3) {
    return { valid: false, message: "Minimo 3 caratteri" };
  }
  return { valid: true, message: "OK" };
}

export function validateVolt(value: string, fieldName: string): ValidationResult {
  if (!value || value.trim() === "") {
    return { valid: false, message: `${fieldName} è obbligatorio` };
  }
  const num = parseFloat(value);
  if (isNaN(num)) {
    return { valid: false, message: "Deve essere un numero valido" };
  }
  return { valid: true, message: "OK" };
}

export function validateDensita(value: string, fieldName: string): ValidationResult {
  if (!value || value.trim() === "") {
    return { valid: false, message: `${fieldName} è obbligatoria` };
  }
  const num = parseFloat(value);
  if (isNaN(num)) {
    return { valid: false, message: "Deve essere un numero valido" };
  }
  if (num < 1.0 || num > 1.4) {
    return { valid: false, message: "Range: 1.0 - 1.4 kg/l" };
  }
  return { valid: true, message: "OK" };
}

export function validateData(value: string): ValidationResult {
  if (!value) {
    return { valid: false, message: "La data è obbligatoria" };
  }
  const date = new Date(value);
  const today = new Date();
  today.setHours(23, 59, 59, 999);
  if (date > today) {
    return { valid: false, message: "La data non può essere nel futuro" };
  }
  return { valid: true, message: "OK" };
}

export function validateRequired(value: string, fieldName: string): ValidationResult {
  if (!value || value.trim() === "") {
    return { valid: false, message: `${fieldName} è obbligatorio` };
  }
  return { valid: true, message: "OK" };
}

export function validateForm(form: Record<string, string>): Record<string, ValidationResult> {
  return {
    data: validateData(form.data || ""),
    tecnico: validateRequired(form.tecnico || "", "Tecnico"),
    cliente: validateRequired(form.cliente || "", "Cliente"),
    modello: validateRequired(form.modello || "", "Tipo Batteria"),
    matricola: validateMatricola(form.matricola || ""),

    volt_vuoto: validateVolt(form.volt_vuoto || "", "Tensione a Vuoto"),
    volt_scarica: validateVolt(form.volt_scarica || "", "Tensione di Scarica"),
    densita_1: validateDensita(form.densita_1 || "", "Densità 1° Elemento"),
    densita_m: validateDensita(form.densita_m || "", "Densità di Mezzo"),
  };
}

export function isFormValid(validations: Record<string, ValidationResult>): boolean {
  return Object.values(validations).every((v) => v.valid);
}
