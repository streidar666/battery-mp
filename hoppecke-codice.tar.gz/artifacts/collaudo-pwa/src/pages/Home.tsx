import { useState, useEffect, useCallback, useMemo } from "react";
import {
  Download,
  Printer,
  Moon,
  Sun,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
  FileText,
  LogOut,
  WifiOff,
  Zap,
} from "lucide-react";
import { HoppeckeLogo } from "@/components/HoppeckeLogo";
import { Button } from "@/components/ui/button";
import { CollaudoForm } from "@/components/CollaudoForm";
import { CollaudoTable } from "@/components/CollaudoTable";
import { AdvancedFilters } from "@/components/AdvancedFilters";
import { StatsPanel } from "@/components/StatsPanel";
import { generateId } from "@/lib/storage";
import { apiGetRecords, apiAddRecord, apiDeleteRecord, apiUpdateBolla } from "@/lib/api";
import { getUsername } from "@/lib/auth";
import { filterRecords, computeStats, exportToCSV } from "@/lib/stats";
import type { CollaudoRecord, CollaudoFilters } from "@/types/collaudo";
import { cn } from "@/lib/utils";

const defaultFilters: CollaudoFilters = {
  esito: "all",
  tecnico: [],
  cliente: [],
  dataFrom: "",
  dataTo: "",
  search: "",
};

const ITEMS_PER_PAGE = 25;

interface HomeProps {
  onLogout: () => void;
}

export default function Home({ onLogout }: HomeProps) {
  const [records, setRecords] = useState<CollaudoRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [filters, setFilters] = useState<CollaudoFilters>(() => {
    try {
      const saved = sessionStorage.getItem("collaudo_filters");
      return saved ? JSON.parse(saved) : defaultFilters;
    } catch {
      return defaultFilters;
    }
  });
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    return (localStorage.getItem("theme") as "dark" | "light") || "dark";
  });
  const [formOpen, setFormOpen] = useState(true);
  const [page, setPage] = useState(1);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  const loadRecords = useCallback(() => {
    setLoading(true);
    setLoadError(null);
    apiGetRecords()
      .then((data) => {
        setRecords(data);
        setLoadError(null);
      })
      .catch((err) => {
        console.error(err);
        setLoadError("Errore di connessione al server. Riprova.");
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    loadRecords();
  }, [loadRecords]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.remove("light");
    } else {
      root.classList.add("light");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  useEffect(() => {
    try {
      sessionStorage.setItem("collaudo_filters", JSON.stringify(filters));
    } catch {
      /* */
    }
    setPage(1);
  }, [filters]);

  const handleSave = useCallback(
    (formData: Omit<CollaudoRecord, "id" | "created_at">) => {
      if (!navigator.onLine) {
        alert("Impossibile salvare — nessuna connessione internet. Riprova quando sei online.");
        return;
      }
      const record: CollaudoRecord = {
        ...formData,
        esito: formData.esito as "Idonea" | "Scarto",
        id: generateId(),
        created_at: new Date().toISOString(),
      };
      setRecords((prev) => [record, ...prev]);
      apiAddRecord(record).catch((err) => {
        console.error("Errore salvataggio:", err);
        alert("Errore nel salvataggio al server. Ricarica la pagina per verificare.");
      });
    },
    []
  );

  const handleDelete = useCallback(async (id: string) => {
    try {
      await apiDeleteRecord(id);
      setRecords((prev) => prev.filter((r) => r.id !== id));
    } catch (err) {
      console.error("Errore eliminazione:", err);
    }
  }, []);

  const handleUpdateBolla = useCallback((id: string, n_bolla: string) => {
    setRecords((prev) =>
      prev.map((r) => (r.id === id ? { ...r, n_bolla } : r))
    );
    apiUpdateBolla(id, n_bolla).catch((err) => {
      console.error("Errore aggiornamento bolla:", err);
      alert("Errore nell'aggiornamento della bolla");
      setRecords((prev) =>
        prev.map((r) => (r.id === id ? { ...r, n_bolla: r.n_bolla } : r))
      );
    });
  }, []);

  const knownTecnici = useMemo(
    () => [...new Set(records.map((r) => r.tecnico).filter(Boolean))].sort(),
    [records]
  );

  const knownClienti = useMemo(
    () => [...new Set(records.map((r) => r.cliente).filter(Boolean))].sort(),
    [records]
  );

  const knownModelli = useMemo(
    () => [...new Set(records.map((r) => r.modello).filter(Boolean))].sort(),
    [records]
  );

  const filteredRecords = useMemo(
    () => filterRecords(records, filters),
    [records, filters]
  );

  const stats = useMemo(() => computeStats(filteredRecords), [filteredRecords]);

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / ITEMS_PER_PAGE));
  const pagedRecords = filteredRecords.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );

  const handlePrint = () => window.print();

  const handleExportCSV = () => exportToCSV(filteredRecords);

  const handleExportPDF = () => {
    const printContent = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<title>Collaudi Battery Report</title>
<style>
  body { font-family: Arial, sans-serif; font-size: 11px; color: #000; }
  h1 { font-size: 16px; color: #4a7c20; }
  .meta { color: #666; font-size: 10px; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #f0f0f0; padding: 4px 6px; text-align: left; border: 1px solid #ccc; font-size: 10px; }
  td { padding: 3px 6px; border: 1px solid #eee; }
  .idonea { color: #2d6b0b; font-weight: bold; }
  .scarto { color: #b91c1c; font-weight: bold; }
  .stats { margin-bottom: 16px; padding: 8px; background: #f9f9f9; border: 1px solid #ddd; display: flex; gap: 24px; }
  .stat { text-align: center; }
  .stat-val { font-size: 18px; font-weight: bold; }
  @page { margin: 15mm; }
</style>
</head>
<body>
<h1>⚡ Report Collaudi Battery</h1>
<div class="meta">Generato il: ${new Date().toLocaleString("it-IT")} · ${filteredRecords.length} record</div>
<div class="stats">
  <div class="stat"><div class="stat-val">${stats.total}</div><div>Totale</div></div>
  <div class="stat"><div class="stat-val" style="color:#2d6b0b">${stats.idonee}</div><div>Idonee</div></div>
  <div class="stat"><div class="stat-val" style="color:#b91c1c">${stats.scarti}</div><div>Scarti</div></div>
  <div class="stat"><div class="stat-val">${stats.scartRate.toFixed(1)}%</div><div>Scarto Rate</div></div>
  ${stats.topTecnico ? `<div class="stat"><div class="stat-val" style="font-size:13px">${stats.topTecnico.name}</div><div>Top Tecnico</div></div>` : ""}
</div>
<table>
<thead><tr>
  <th>Data</th><th>Esito</th><th>Tecnico</th><th>Cliente</th><th>Tipo Batteria</th>
  <th>Matricola</th><th>N. Bolla</th><th>T. Vuoto</th><th>T. Scarica</th><th>Den. 1° El.</th><th>Den. Mezzo</th>
</tr></thead>
<tbody>
${filteredRecords
  .map(
    (r) => `<tr>
  <td>${r.data}</td>
  <td class="${r.esito === "Idonea" ? "idonea" : "scarto"}">${r.esito}</td>
  <td>${r.tecnico}</td><td>${r.cliente}</td><td>${r.modello}</td>
  <td>${r.matricola}</td><td>${r.n_bolla}</td>
  <td>${r.volt_vuoto}V</td><td>${r.volt_scarica}V</td>
  <td>${r.densita_1}</td><td>${r.densita_m}</td>
</tr>`
  )
  .join("")}
</tbody>
</table>
</body>
</html>`;
    const w = window.open("", "_blank");
    if (w) {
      w.document.write(printContent);
      w.document.close();
      w.focus();
      setTimeout(() => {
        w.print();
        w.close();
      }, 300);
    }
  };

  if (loading && records.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm text-muted-foreground">Caricamento dati...</p>
        </div>
      </div>
    );
  }

  if (loadError && records.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center max-w-sm">
          <p className="text-lg font-semibold text-foreground mb-2">Connessione al server fallita</p>
          <p className="text-sm text-muted-foreground mb-6">{loadError}</p>
          <button
            onClick={loadRecords}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90"
          >
            Riprova
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Offline banner */}
      {!isOnline && (
        <div className="sticky top-0 z-50 bg-orange-500/95 text-white text-xs font-semibold flex items-center justify-center gap-2 py-2 px-4 no-print">
          <WifiOff className="w-3.5 h-3.5 shrink-0" />
          Nessuna connessione — i dati non possono essere salvati o caricati finché non torni online.
        </div>
      )}
      {/* Header */}
      <header className="border-b border-border bg-card/80 sticky top-0 z-30 backdrop-blur-sm no-print">
        <div className="flex items-center justify-between px-4 py-2.5">
          <div className="flex items-center gap-3">
            <HoppeckeLogo height={20} variant="dark" />
            <div>
              <h1 className="text-sm font-bold text-foreground leading-none">Battery Check</h1>
              <p className="text-[10px] text-muted-foreground">Sistema Gestione Collaudi</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${isOnline ? "bg-green-500" : "bg-red-500"}`}
              title={isOnline ? "Online" : "Offline"}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePrint}
              className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              title="Stampa"
              data-testid="button-print"
            >
              <Printer className="w-3.5 h-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExportCSV}
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
              title="Esporta Excel"
              data-testid="button-export-csv"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Excel</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExportPDF}
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
              title="Esporta PDF"
              data-testid="button-export-pdf"
            >
              <FileText className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PDF</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
              className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              title="Cambia tema"
              data-testid="button-theme-toggle"
            >
              {theme === "dark" ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-red-400"
              title={`Esci (${getUsername() ?? ""})`}
              data-testid="button-logout"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Esci</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Form */}
        <aside
          className={cn(
            "border-r border-border bg-card/50 flex flex-col transition-all duration-300 no-print",
            formOpen ? "w-72 min-w-[240px]" : "w-8 min-w-[32px]"
          )}
        >
          <div className="flex items-center justify-between px-3 py-2 border-b border-border">
            {formOpen && (
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Nuovo Collaudo
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setFormOpen((o) => !o)}
              className="h-6 w-6 p-0 ml-auto text-muted-foreground hover:text-foreground"
              data-testid="button-toggle-form"
            >
              {formOpen ? (
                <ChevronLeft className="w-3.5 h-3.5" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5" />
              )}
            </Button>
          </div>
          {formOpen && (
            <div className="flex-1 overflow-y-auto p-3">
              <CollaudoForm
                onSave={handleSave}
                knownTecnici={knownTecnici}
                knownClienti={knownClienti}
                knownModelli={knownModelli}
              />
            </div>
          )}
        </aside>

        {/* Right Panel - Table */}
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            <div className="p-3 space-y-3">
              {/* Stats */}
              <StatsPanel stats={stats} />

              {/* Filters */}
              <AdvancedFilters
                filters={filters}
                onChange={setFilters}
                tecnici={knownTecnici}
                clienti={knownClienti}
                filteredCount={filteredRecords.length}
                totalCount={records.length}
              />

              {/* Print header */}
              <div className="print-only">
                <h2 className="text-lg font-bold">Report Collaudi Battery</h2>
                <p className="text-sm text-gray-500">
                  {filteredRecords.length} record · Generato il {new Date().toLocaleString("it-IT")}
                </p>
              </div>

              {/* Table */}
              <div className="border border-border rounded-lg bg-card overflow-hidden">
                <div className="flex items-center justify-between px-3 py-2 border-b border-border no-print">
                  <span className="text-xs font-semibold text-muted-foreground">
                    <span className="text-foreground font-bold">{filteredRecords.length}</span>
                    {" "}record
                    {records.length !== filteredRecords.length && (
                      <span className="text-muted-foreground"> di {records.length}</span>
                    )}
                  </span>
                  {totalPages > 1 && (
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={page <= 1}
                        onClick={() => setPage((p) => p - 1)}
                        className="h-6 w-6 p-0"
                        data-testid="button-prev-page"
                      >
                        <ChevronLeft className="w-3 h-3" />
                      </Button>
                      <span className="text-xs text-muted-foreground">
                        {page} / {totalPages}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={page >= totalPages}
                        onClick={() => setPage((p) => p + 1)}
                        className="h-6 w-6 p-0"
                        data-testid="button-next-page"
                      >
                        <ChevronRight className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </div>
                <CollaudoTable records={pagedRecords} onDelete={handleDelete} onUpdateBolla={handleUpdateBolla} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
