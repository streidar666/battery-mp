import { useState } from "react";
import { Eye, EyeOff, LogIn } from "lucide-react";
import { HoppeckeLogo } from "@/components/HoppeckeLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiLogin } from "@/lib/api";
import { setAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

interface Props {
  onLogin: () => void;
}

export default function Login({ onLogin }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Inserisci username e password");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const { token, username: user } = await apiLogin(username.trim(), password);
      setAuth(token, user);
      onLogin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Credenziali non valide");
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    "bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary/30 h-10 text-sm";

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8 gap-3">
          <HoppeckeLogo height={32} variant="dark" />
          <div className="text-center">
            <h1 className="text-lg font-bold text-foreground">Database Battery Check</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Accedi per continuare</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-xs text-muted-foreground mb-1 block">
                Username
              </Label>
              <Input
                id="username"
                type="text"
                autoComplete="username"
                autoFocus
                value={username}
                onChange={(e) => { setUsername(e.target.value); setError(""); }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    document.getElementById("password")?.focus();
                  }
                }}
                placeholder="Inserisci username"
                className={inputClass}
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-xs text-muted-foreground mb-1 block">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  placeholder="Inserisci password"
                  className={cn(inputClass, "pr-10")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-xs text-red-400 text-center">{error}</p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-10 font-semibold gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {loading ? (
                <span className="animate-spin inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
              ) : (
                <LogIn className="w-4 h-4" />
              )}
              {loading ? "Accesso in corso..." : "Accedi"}
            </Button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          Sistema riservato — accesso consentito solo al personale autorizzato
        </p>
      </div>
    </div>
  );
}
