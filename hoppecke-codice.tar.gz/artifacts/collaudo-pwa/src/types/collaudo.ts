export interface CollaudoRecord {
  id: string;
  data: string;
  esito: "Idonea" | "Scarto";
  tecnico: string;
  cliente: string;
  modello: string;
  matricola: string;
  n_bolla: string;
  volt_vuoto: string;
  volt_scarica: string;
  densita_1: string;
  densita_m: string;
  created_at: string;
}

export interface CollaudoFilters {
  esito: string;
  tecnico: string[];
  cliente: string[];
  dataFrom: string;
  dataTo: string;
  search: string;
}

export interface CollaudoStats {
  total: number;
  idonee: number;
  scarti: number;
  scartRate: number;
  topTecnico: { name: string; count: number } | null;
  topCliente: { name: string; count: number } | null;
  trend7d: { date: string; count: number }[];
  tecnici: { name: string; count: number }[];
  clienti: { name: string; count: number }[];
}

export type ValidationResult = {
  valid: boolean;
  message: string;
};

export type FieldValidation = Record<string, ValidationResult>;
