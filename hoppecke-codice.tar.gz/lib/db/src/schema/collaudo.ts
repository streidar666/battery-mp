import { pgTable, text, date, timestamp } from "drizzle-orm/pg-core";

export const collaudoRecords = pgTable("collaudo_records", {
  id: text("id").primaryKey(),
  data: date("data").notNull(),
  esito: text("esito").notNull(),
  tecnico: text("tecnico").notNull(),
  cliente: text("cliente").notNull(),
  modello: text("modello").notNull(),
  matricola: text("matricola").notNull(),
  n_bolla: text("n_bolla"),
  volt_vuoto: text("volt_vuoto").notNull(),
  volt_scarica: text("volt_scarica").notNull(),
  densita_1: text("densita_1").notNull(),
  densita_m: text("densita_m").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type CollaudoRecord = typeof collaudoRecords.$inferSelect;
export type InsertCollaudoRecord = typeof collaudoRecords.$inferInsert;
